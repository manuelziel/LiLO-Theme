<?php
/**
 * The template for displaying post excerpts
 *
 * @version 1.0
 * @package Dynamico
 */
?>

<div class="entry-content entry-excerpt">

	<?php the_excerpt(); ?>
	<?php dynamico_more_link(); ?>

</div><!-- .entry-content -->
