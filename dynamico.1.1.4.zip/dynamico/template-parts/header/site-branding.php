<?php
/**
 * Site Branding
 *
 * @version 1.0
 * @package Dynamico
 */
?>

<div class="site-branding">

	<?php dynamico_site_title(); ?>
	<?php dynamico_site_description(); ?>

</div><!-- .site-branding -->
